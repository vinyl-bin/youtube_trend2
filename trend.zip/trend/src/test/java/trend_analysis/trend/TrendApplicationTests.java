package trend_analysis.trend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrendApplicationTests {

	@Test
	void contextLoads() {
	}

}
