package com.cookiek.commenthat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommenthatApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommenthatApplication.class, args);
	}

}
