package com.cookiek.commenthat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommenthatApplicationTests {

	@Test
	void contextLoads() {
	}

}
